//
//  CaftoMp3Instrument.h
//  TransformCartoMp3_Demo
//
//  Created by bioongroup on 15/11/5.
//  Copyright © 2015年 ylk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CaftoMp3Instrument : NSObject
@property (nonatomic,assign)NSString *inputFilePath;//文件输入路径
@property (nonatomic,assign)NSString *outputFilePath;//转换完成的文件输出路径
-(void)starTransform;//开始转换
-(instancetype)initWithinputPath:(NSString*)inputPath andOutputPath:(NSString*)outputPath;//初始化方法
@end
