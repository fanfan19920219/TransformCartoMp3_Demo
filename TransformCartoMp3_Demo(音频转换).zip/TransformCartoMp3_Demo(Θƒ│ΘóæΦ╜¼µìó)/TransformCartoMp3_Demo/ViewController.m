//
//  ViewController.m
//  TransformCartoMp3_Demo
//
//  Created by bioongroup on 15/11/5.
//  Copyright © 2015年 ylk. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "CaftoMp3Instrument.h"
@interface ViewController ()<AVAudioRecorderDelegate>{
    UIButton *_starRecordBtn;//录音的按钮
    UIButton *_transformBtn;//转换格式的按钮(mp3)
    AVAudioPlayer *_audioPlayer;//音频播放器
    AVAudioRecorder *_audioRecorder;
    BOOL orRecord;//标记是否录音
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"沙盒路径------%@",NSHomeDirectory());
    // Do any additional setup after loading the view, typically from a nib.
    [self setAudioSession];
}

-(NSString*)mp3Path {//mp3文件路径
    return [NSTemporaryDirectory() stringByAppendingString:@"file.mp3"];
}
-(NSString*)cafPath {//caf文件路径
    return [NSTemporaryDirectory() stringByAppendingString:@"file.caf"];
}

-(IBAction)starRecord:(UIButton*)sender {//开始录音？
    (orRecord==YES)?  [self.audioRecorder stop]:[self.audioRecorder record];
    orRecord = !orRecord;
    sender.selected = orRecord;
}
-(IBAction)starTransform:(id)sender {
    NSString *inputPath = [self cafPath];
    NSString *outPutPath = [self mp3Path];
    CaftoMp3Instrument *transform = [[CaftoMp3Instrument alloc]initWithinputPath:inputPath andOutputPath:outPutPath];
    [transform starTransform];
}
-(AVAudioPlayer *)audioPlayer {//配置audioPlayer
    if (!_audioPlayer) {
        NSURL *url=[NSURL URLWithString:[self mp3Path]];
        NSError *error=nil;
        _audioPlayer=[[AVAudioPlayer alloc]initWithContentsOfURL:url error:&error];
        _audioPlayer.delegate = self;
        _audioPlayer.numberOfLoops=0;
        [_audioPlayer prepareToPlay];
        if (error) {
            NSLog(@"创建播放器过程中发生错误，错误信息：%@",error.localizedDescription);
            return nil;
        }
    }return _audioPlayer;
}
-(IBAction)play:(id)sender {//播放
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    NSError *err = nil;
    [audioSession setCategory :AVAudioSessionCategoryPlayback error:&err];
    [self.audioPlayer play];
    NSLog(@"播放录音");
}

-(void)setAudioSession{
    AVAudioSession *audioSession=[AVAudioSession sharedInstance];
    //设置为播放和录音状态，以便可以在录制完之后播放录音
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [audioSession setActive:YES error:nil];
}
#pragma  -   AVAudioDelegate
-(NSDictionary *)getAudioSetting {//配置ReCord
    //....其他设置等
    NSMutableDictionary *settings = [[NSMutableDictionary alloc] init];
    //录音格式 无法使用
    [settings setValue :[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey: AVFormatIDKey];
    //采样率
    [settings setValue :[NSNumber numberWithFloat:11025.0] forKey: AVSampleRateKey];//44100.0
    //通道数
    [settings setValue :[NSNumber numberWithInt:2] forKey: AVNumberOfChannelsKey];
    //音频质量,采样质量
    [settings setValue:[NSNumber numberWithInt:AVAudioQualityMin] forKey:AVEncoderAudioQualityKey];
    return settings;
}

-(AVAudioRecorder *)audioRecorder {
    NSLog(@"创建录音机");
    if (!_audioRecorder) {
        //创建录音文件保存路径
        NSURL *url=[NSURL URLWithString:[self cafPath]];
        //创建录音格式设置
        NSDictionary *setting=[self getAudioSetting];
        //创建录音机
        NSError *error=nil;
        _audioRecorder=[[AVAudioRecorder alloc]initWithURL:url settings:setting error:&error];
        _audioRecorder.delegate=self;
        _audioRecorder.meteringEnabled=YES;//如果要监控声波则必须设置为YES
        if (error) {
            NSLog(@"创建录音机对象时发生错误，错误信息：%@",error.localizedDescription);
            return nil;
        }
    }return _audioRecorder;
}

-(void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag{
    NSLog(@"录音完成");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
